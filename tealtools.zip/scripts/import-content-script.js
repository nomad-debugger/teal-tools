!function(){const t=JSON.parse('"scripts/content-script.js"');import(chrome.runtime.getURL(t));}();
