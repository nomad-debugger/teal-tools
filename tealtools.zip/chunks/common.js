import { n } from './cleanShare.js';

function e(s,e){window.postMessage({from:s,pong:e});}function o(s,e){window.addEventListener("message",(o=>{const r=o.data;r.from===s&&"ping"in r&&e(r.ping);}));}function r(o){self.addEventListener("error",(r=>{var n$1;"processed"in r&&r.processed&&Array.isArray(r.processed)&&r.processed.includes(o)||(null!==(n$1=r.processed)&&void 0!==n$1||(r.processed=[]),r.processed.push(o),e("cs_tool_error",{tool:o,...n(r,"cs-file")}));}));}

export { e, o, r };
