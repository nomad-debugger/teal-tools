let t;function o(o){t&&t.abort(),t=new AbortController;const n=document.querySelectorAll("#tags .tc-box-row");n&&n.forEach((n=>n.addEventListener("click",a.bind(n,o),{signal:t.signal})));}function a(t){const{account:o,profile:a,env:n}=t.data.details.details;chrome.tabs.create({url:`https://tags.tiqcdn.com/utag/${o}/${a}/${n}/utag.`+this.id+".js?_cb="+Math.random(),active:!1});}function n(){t&&(t.abort(),t=void 0);}

export { n as cleanup, o as init };
