let o;function r(r){o&&o.abort(),o=new AbortController,"import"!==r.scriptId&&tealiumTools.sendError("Unknown UI-Code for Script Called",JSON.stringify(r,null,2));}function t(){o&&(o.abort(),o=void 0);}

export { t as cleanup, r as init };
