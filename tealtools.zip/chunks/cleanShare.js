function n(e,o){var r,t;const a=e.stack||(e.error instanceof Error?e.error.stack||"":function(){const e=((new Error).stack||"").split("\n");for(let o=0;o<e.length;o++){const r=e[o];if(e.splice(o,1),o--,r.includes(`at ${n.name}`))break}return e.join("\n")}());return {colno:null!==(r=e.colno)&&void 0!==r?r:0,lineno:null!==(t=e.lineno)&&void 0!==t?t:0,filename:e.filename,message:e.message||"unknown error",type:e.type,timestamp:Date.now(),location:o,stack:a}}

export { n };
