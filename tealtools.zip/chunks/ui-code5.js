import { E } from './cash.esm.js';

let o;function a(a){switch(o&&o.abort(),o=new AbortController,a.scriptId){case"search_custom":case"search_page":return void E(".collapse").on("shown.bs.collapse",(function(){E(this).prev().find(".fa6-plus").removeClass("fa6-plus").addClass("fa6-minus");})).on("hidden.bs.collapse",(function(){E(this).prev().find(".fa6-minus").removeClass("fa6-minus").addClass("fa6-plus");}));default:tealiumTools.sendError("Unknown UI-Code for Script Called",JSON.stringify(a,null,2));}}function e(){o&&(o.abort(),o=void 0);}

export { e as cleanup, a as init };
